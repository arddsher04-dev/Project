const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();

const app = express();

// --- 1. MIDDLEWARE ---
app.use(cors()); 
app.use(express.json()); 

// --- 2. DATABASE CONNECTION ---
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("✅ MongoDB Connected Successfully"))
  .catch((err) => console.log("❌ MongoDB Connection Error:", err));

// --- 3. USER MODEL ---
const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, default: "Student" },
  enrolledCourses: { type: Array, default: [] } // Storing IDs as numbers/strings
});

const User = mongoose.model("User", userSchema);

// --- 4. ROUTES ---

// REGISTER
app.post("/api/auth/register", async (req, res) => {
  try {
    const { name, email, password, role } = req.body;
    const userExists = await User.findOne({ email });
    if (userExists) return res.status(400).json({ error: "Email already exists" });

    const newUser = new User({ name, email, password, role });
    await newUser.save();
    res.status(201).json({ user: { id: newUser._id, name: newUser.name, role: newUser.role } });
  } catch (error) {
    res.status(500).json({ error: "Registration Error" });
  }
});

// LOGIN
app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password, role } = req.body;
    const user = await User.findOne({ email });
    if (!user || user.password !== password || user.role !== role) {
      return res.status(400).json({ error: "Invalid Credentials or Role" });
    }
    res.status(200).json({
      user: { id: user._id, name: user.name, email: user.email, role: user.role }
    });
  } catch (error) {
    res.status(500).json({ error: "Login Error" });
  }
});

// ENROLL IN A COURSE
app.post("/api/student/enroll", async (req, res) => {
  try {
    const { userId, courseId } = req.body;
    const user = await User.findByIdAndUpdate(
      userId,
      { $addToSet: { enrolledCourses: courseId } }, 
      { new: true }
    );
    if (!user) return res.status(404).json({ error: "User not found" });
    res.status(200).json({ message: "Enrolled!", enrolledCourses: user.enrolledCourses });
  } catch (error) {
    res.status(500).json({ error: "Enrollment failed" });
  }
});

// GET STUDENT ENROLLED IDS
app.get("/api/student/my-courses/:userId", async (req, res) => {
  try {
    const user = await User.findById(req.params.userId);
    if (!user) return res.status(404).json({ error: "User not found" });
    res.status(200).json(user.enrolledCourses); 
  } catch (error) {
    res.status(500).json({ error: "Fetch failed" });
  }
});

// --- 5. START SERVER ---
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server on http://localhost:${PORT}`));

// --- Inside your server.js, before app.listen ---

// Add this to stop the "Cannot GET /" error
app.get("/", (req, res) => {
  res.send("Backend Server is Running Successfully!");
});

// Update this to handle the 404 for courses properly
// (This is why your frontend might be failing to fetch)
app.get("/api/courses", (req, res) => {
  // Sending the same fallback data from backend if DB is empty
  const courses = [
    { id: 1, title: "MERN Stack Mastery 2026", price: 129, thumbnail: "..." },
    { id: 2, title: "Next.js 15 Guide", price: 89, thumbnail: "..." },
    { id: 3, title: "Docker & Kubernetes", price: 149, thumbnail: "..." }
  ];
  res.status(200).json(courses);
});

// --- ADMIN: GET ALL USERS ---
app.get("/api/admin/users", async (req, res) => {
  try {
    const users = await User.find({}, "-password");
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch users" });
  }
});

app.post("/api/admin/add-course", async (req, res) => {
  try {
    res.status(201).json({ message: "Course feature ready to be linked with DB!" });
  } catch (err) {
    res.status(500).json({ error: "Failed to add course" });
  }

exports.enrollInCourse = async (req, res) => {
  const { userId, courseId } = req.body;
  
  console.log("Enrollment Request for User:", userId, "Course:", courseId); // Debugging

  try {
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ message: "User not found" });

    if (user.enrolledCourses.includes(courseId)) {
      return res.status(400).json({ message: "You are already enrolled in this course!" });
    }

    user.enrolledCourses.push(courseId);
    await user.save();

    res.status(200).json({ message: "Enrolled successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};
});

app.delete("/api/admin/users/:id", async (req, res) => {
  await User.findByIdAndDelete(req.params.id);
  res.json({ message: "User deleted" });
});

const Course = require("./models/Course");

app.get("/api/student/my-courses/:userId", async (req, res) => {
  try {
    const user = await User.findById(req.params.userId).populate("enrolledCourses");
    
    if (!user) return res.status(404).json({ error: "User not found" });

    res.status(200).json(user.enrolledCourses); 
  } catch (error) {
    console.error("Dashboard Fetch Error:", error);
    res.status(500).json({ error: "Failed to fetch dashboard data" });
  }
});


app.post("/api/courses/create", async (req, res) => {
  try {
    const newCourse = new Course(req.body);
    await newCourse.save();
    res.status(201).json(newCourse);
  } catch (err) {
    res.status(400).json({ error: "Course create nahi hua" });
  }
});

app.delete("/api/courses/:id", async (req, res) => {
  try {
    await Course.findByIdAndDelete(req.params.id);
    res.json({ message: "Course delete ho gaya" });
  } catch (err) {
    res.status(500).json({ error: "Delete failed" });
  }
});