const mongoose = require("mongoose");

const courseSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  price: { type: Number, required: true },
  category: { type: String, required: true },
  thumbnail: { type: String, required: true },
  
 
  instructorId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: "User", 
    required: true 
  },
  
  lessons: [
    {
      title: { type: String, required: true },
      videoUrl: { type: String, required: true }, 
      duration: { type: String } 
    }
  ],
  
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Course", courseSchema);