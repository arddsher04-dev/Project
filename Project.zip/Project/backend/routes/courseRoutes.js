const express = require("express");
const router = express.Router();

const courses = [
  { 
    id: 1, 
    title: "MERN Stack Mastery 2026", 
    description: "Build a production-grade SaaS application with React 19 and Node.js.",
    category: "Full Stack", 
    price: 129, 
    thumbnail: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=800" 
  },
  { 
    id: 2, 
    title: "Next.js 15: The Ultimate Guide", 
    description: "Master Server Components and App Router architecture.",
    category: "Frontend", 
    price: 89, 
    thumbnail: "https://images.unsplash.com/photo-1618477388954-7852f32655ec?w=800" 
  },
  { 
    id: 3, 
    title: "Docker & Kubernetes for Engineers", 
    description: "Containerize applications and deploy at scale.",
    category: "DevOps", 
    price: 149, 
    thumbnail: "https://images.unsplash.com/photo-1605745341112-85968b193ef5?w=800"
  },
  { 
    id: 4, 
    title: "Advanced TypeScript Patterns", 
    description: "Master generics and type-safe libraries.",
    category: "Frontend", 
    price: 59, 
    thumbnail: "https://images.unsplash.com/photo-1516116216624-53e697fedbea?w=800" 
  },
  { 
    id: 5, 
    title: "AI Integrations with OpenAI API", 
    description: "Build intelligent chatbots and automation tools.",
    category: "AI/ML", 
    price: 199, 
    thumbnail: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800" 
  },
  { 
    id: 6, 
    title: "Python for Data Engineering", 
    description: "Architect big data pipelines with PySpark.",
    category: "Data Science", 
    price: 110, 
    thumbnail: "https://images.unsplash.com/photo-1527474305487-b87b222841cc?w=800"
  },
  { 
    id: 7, 
    title: "Mobile Dev with React Native", 
    description: "Build cross-platform iOS and Android apps.",
    category: "Mobile", 
    price: 95, 
    thumbnail: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=800" 
  },
  { 
    id: 8, 
    title: "Cybersecurity Fundamentals", 
    description: "Protect applications from OWASP Top 10 vulnerabilities.",
    category: "Security", 
    price: 155, 
    thumbnail: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800" 
  }
];

router.get("/", (req, res) => {
  res.status(200).json(courses);
});

module.exports = router;