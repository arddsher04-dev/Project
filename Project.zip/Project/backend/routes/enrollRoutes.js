const router = require("express").Router()
const Enrollment = require("../models/Enrollment")
const auth = require("../middleware/authMiddleware")

router.post("/", auth, async(req,res)=>{

 const enroll = await Enrollment.create({
  student:req.user.id,
  course:req.body.course
 })

 res.json(enroll)

})

router.get("/my-courses", auth, async(req,res)=>{

 const courses = await Enrollment
 .find({student:req.user.id})
 .populate("course")

 res.json(courses)

})

module.exports = router