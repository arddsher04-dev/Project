import React from "react";
import { Link } from "react-router-dom";

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-dark text-white pt-5 pb-4 mt-5">
      <style>{`
        .footer-link {
          transition: all 0.3s ease;
          opacity: 0.6;
        }
        .footer-link:hover {
          opacity: 1;
          color: #4f46e5 !important;
          padding-left: 5px;
        }
        .social-icon {
          width: 36px;
          height: 36px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          background: rgba(255,255,255,0.1);
          transition: 0.3s;
          margin-right: 10px;
        }
        .social-icon:hover {
          background: #4f46e5;
          transform: translateY(-3px);
        }
        .newsletter-input:focus {
          box-shadow: none;
          border-color: #4f46e5;
        }
      `}</style>

      <div className="container">
        <div className="row g-5">
          {/* BRAND COLUMN */}
          <div className="col-lg-4 col-md-6">
            <h3 className="fw-bold mb-3 text-primary">Edu<span className="text-white">MERN</span></h3>
            <p className="text-white-50 mb-4" style={{ lineHeight: '1.8' }}>
              The world's most project-focused engineering platform. Build real apps, get real experience, and land your dream job in tech.
            </p>
            <div className="d-flex">
              <a href="#" className="social-icon text-white text-decoration-none">𝕏</a>
              <a href="#" className="social-icon text-white text-decoration-none">in</a>
              <a href="#" className="social-icon text-white text-decoration-none">git</a>
            </div>
          </div>

          {/* QUICK LINKS */}
          <div className="col-6 col-lg-2">
            <h6 className="fw-bold text-uppercase small mb-4 tracking-wider">Explore</h6>
            <ul className="list-unstyled">
              <li className="mb-2"><Link to="/home" className="footer-link text-white text-decoration-none">Home</Link></li>
              <li className="mb-2"><Link to="/courses" className="footer-link text-white text-decoration-none">Courses</Link></li>
              <li className="mb-2"><Link to="/about" className="footer-link text-white text-decoration-none">About</Link></li>
              <li className="mb-2"><Link to="/faq" className="footer-link text-white text-decoration-none">FAQ</Link></li>
            </ul>
          </div>

          {/* SUPPORT */}
          <div className="col-6 col-lg-2">
            <h6 className="fw-bold text-uppercase small mb-4 tracking-wider">Support</h6>
            <ul className="list-unstyled">
              <li className="mb-2"><a href="/contact" className="footer-link text-white text-decoration-none">Contact</a></li>
              <li className="mb-2"><a href="#" className="footer-link text-white text-decoration-none">Help Center</a></li>
              <li className="mb-2"><a href="#" className="footer-link text-white text-decoration-none">Privacy Policy</a></li>
              <li className="mb-2"><a href="#" className="footer-link text-white text-decoration-none">Terms of Service</a></li>
            </ul>
          </div>

          {/* NEWSLETTER */}
          <div className="col-lg-4">
            <h6 className="fw-bold text-uppercase small mb-4 tracking-wider">Stay Updated</h6>
            <p className="text-white-50 small mb-3">Get the latest engineering insights delivered to your inbox weekly.</p>
            <div className="input-group mb-3">
              <input 
                type="email" 
                className="form-control bg-transparent border-secondary text-white newsletter-input" 
                placeholder="Email Address" 
              />
              <button className="btn btn-primary px-4 fw-bold">Join</button>
            </div>
            <span className="text-white-50" style={{ fontSize: '0.7rem' }}>
              Join 12,000+ developers already subscribed.
            </span>
          </div>
        </div>

        <hr className="my-5 opacity-10" />

        {/* BOTTOM BAR */}
        <div className="row align-items-center">
          <div className="col-md-6 text-center text-md-start">
            <span className="text-white-50 small">© 2026 EduMERN Learning Solutions. All rights reserved.</span>
          </div>
          <div className="col-md-6 text-center text-md-end mt-3 mt-md-0">
            <button 
              onClick={scrollToTop} 
              className="btn btn-link text-white-50 text-decoration-none small p-0 border-0"
            >
              Back to Top ↑
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;