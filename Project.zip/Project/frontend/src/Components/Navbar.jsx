import React, { useState, useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";

const Navbar = () => {
  const [user, setUser] = useState(null);
  const [scrolled, setScrolled] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    setUser(storedUser ? JSON.parse(storedUser) : null);
  }, [location]);

  const handleLogout = () => {
    localStorage.removeItem("user");
    setUser(null);
    navigate("/login");
  };

  return (
    <nav 
      className={`navbar navbar-expand-lg fixed-top ${
        scrolled ? "bg-white shadow-lg py-2" : "bg-dark shadow-none py-3"
      }`}
      style={{ transition: "all 0.4s cubic-bezier(0.4, 0, 0.2, 1)" }}
    >
      <div className="container">
        {/* LOGO */}
        <Link className={`navbar-brand fw-bolder fs-3 d-flex align-items-center ${scrolled ? "text-indigo" : "text-white"}`} to="/">
          <span className="me-2" style={{ color: "#6366f1" }}>◈</span>
          Edu<span style={{ color: "#6366f1" }}>MERN</span>
        </Link>

        {/* MOBILE TOGGLE */}
        <button className="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">
          {/* MAIN MENUS */}
          <ul className="navbar-nav ms-auto mb-2 mb-lg-0 align-items-center">
            <li className="nav-item">
              <Link className={`nav-link px-3 fw-semibold ${scrolled ? "text-secondary" : "text-white-50"}`} to="/">Home</Link>
            </li>
            
            {/* CATEGORIES DROPDOWN */}
            <li className="nav-item dropdown">
              <Link className={`nav-link dropdown-toggle px-3 fw-semibold ${scrolled ? "text-secondary" : "text-white-50"}`} to="#" data-bs-toggle="dropdown">
                Categories
              </Link>
              <ul className="dropdown-menu border-0 shadow-lg fade-up">
                <li><Link className="dropdown-item" to="/courses?cat=web">Web Development</Link></li>
                <li><Link className="dropdown-item" to="/courses?cat=data">Data Science</Link></li>
                <li><Link className="dropdown-item" to="/courses?cat=design">UI/UX Design</Link></li>
              </ul>
            </li>

            <li className="nav-item">
              <Link className={`nav-link px-3 fw-semibold ${scrolled ? "text-secondary" : "text-white-50"}`} to="/courses">Courses</Link>
            </li>
            
            <li className="nav-item">
              <Link className={`nav-link px-3 fw-semibold ${scrolled ? "text-secondary" : "text-white-50"}`} to="/about">About Us</Link>
            </li>
          </ul>

          {/* RIGHT SIDE: SEARCH & AUTH */}
          <div className="d-flex align-items-center ms-lg-4 gap-3">
            {user ? (
              <div className="dropdown">
                <button 
                  className={`btn d-flex align-items-center gap-2 rounded-pill px-2 py-1 ${
                    scrolled ? "btn-light border" : "btn-outline-light"
                  }`} 
                  type="button" 
                  data-bs-toggle="dropdown"
                >
                  <div className="avatar-circle">{user.name.charAt(0).toUpperCase()}</div>
                  <span className="fw-bold small d-none d-md-inline">{user.name}</span>
                </button>
                
                <ul className="dropdown-menu dropdown-menu-end border-0 shadow-xl mt-3 p-2 animate slideIn">
                  <li className="p-3 text-center border-bottom mb-2 bg-light rounded-3">
                    <p className="mb-0 fw-bold text-indigo">{user.name}</p>
                    <span className="badge bg-indigo-subtle text-indigo p-1" style={{fontSize: "10px"}}>{user.role}</span>
                  </li>
                  <li>
                    <Link className="dropdown-item rounded-2" to={
                        user?.role === "Student" ? "/student-dashboard" :
                        user?.role === "Instructor" ? "/instructor-dashboard" : "/admin-dashboard"
                    }>📊 My Dashboard</Link>
                  </li>
                  <li><Link className="dropdown-item rounded-2" to="/profile">👤 My Profile</Link></li>
                  <li><hr className="dropdown-divider" /></li>
                  <li>
                    <button className="dropdown-item text-danger fw-bold rounded-2" onClick={handleLogout}>🚪 Logout</button>
                  </li>
                </ul>
              </div>
            ) : (
              <div className="d-flex gap-2">
                <Link to="/login" className={`btn fw-bold px-3 ${scrolled ? "text-dark" : "text-white"}`}>Login</Link>
                <Link to="/register" className="btn btn-indigo rounded-pill px-4 shadow fw-bold">Sign Up</Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;