import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";

// BOOTSTRAP & CSS
import "bootstrap/dist/css/bootstrap.min.css"; 
import "bootstrap/dist/js/bootstrap.bundle.min.js";
import "./App.css";

// COMPONENTS
import Navbar from "./Components/Navbar";
import Footer from "./Components/Footer";
import ProtectedRoute from "./pages/ProtectedRoute";
import Profile from "./pages/Profile"; // Profile component import kiya

// PAGES
import Home from "./pages/Home";
import Courses from "./pages/Courses";
import About from "./pages/About";
import Faq from "./pages/Faq";
import Login from "./pages/Login";
import Register from "./pages/Register";
import StudentDashboard from "./pages/StudentDashboard";
import AdminDashboard from "./pages/AdminDashboard";
import InstructorDashboard from "./pages/InstructorDashboard";

function App() {
  return (
    <> 
      <Navbar />
      <main style={{ minHeight: "80vh" }}>
        <Routes>
          {/* --- PUBLIC ROUTES --- */}
          <Route path="/" element={<Home />} />
          <Route path="/courses" element={<Courses />} />
          <Route path="/about" element={<About />} />
          <Route path="/faq" element={<Faq />} /> 
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          
          {/* --- PROFILE ROUTE --- */}
          <Route path="/profile" element={<Profile />} />

          {/* --- DASHBOARDS (WITHOUT PROTECTION FOR TESTING) --- */}
          <Route path="/admin-dashboard" element={<AdminDashboard />} />
          <Route path="/instructor-dashboard" element={<InstructorDashboard />} />

          {/* --- PROTECTED STUDENT DASHBOARD --- */}
          <Route 
            path="/student-dashboard" 
            element={
              <ProtectedRoute allowedRoles={["Student"]}>
                <StudentDashboard />
              </ProtectedRoute>
            } 
          />

          {/* REDIRECT UNKNOWN ROUTES TO HOME */}
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </main>
      <Footer />
    </>
  );
}

export default App;