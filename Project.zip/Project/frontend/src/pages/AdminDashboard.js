import React, { useState, useEffect } from "react";
import axios from "axios";

const AdminDashboard = () => {
  const [users, setUsers] = useState([]);
  const [courses, setCourses] = useState([]);
  const [activeTab, setActiveTab] = useState("users");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchData();
  }, [activeTab]);

  const fetchData = async () => {
    setLoading(true);
    try {
      if (activeTab === "users") {
        const res = await axios.get("http://localhost:5000/api/admin/users");
        setUsers(res.data);
      } else {
        const res = await axios.get("http://localhost:5000/api/courses");
        setCourses(res.data);
      }
    } catch (err) {
      console.error("Data fetching failed:", err);
    } finally {
      setLoading(false);
    }
  };

  const deleteUser = async (id) => {
    if (window.confirm("Are you sure you want to delete this user?")) {
      try {
        await axios.delete(`http://localhost:5000/api/admin/users/${id}`);
        setUsers(users.filter(u => u._id !== id));
        alert("User removed.");
      } catch (err) {
        alert("Error deleting user.");
      }
    }
  };

  const deleteCourse = async (id) => {
    if (window.confirm("Delete this course permanently?")) {
      try {
        await axios.delete(`http://localhost:5000/api/admin/courses/${id}`);
        setCourses(courses.filter(c => (c.id || c._id) !== id)); 
        alert("Course deleted!");
      } catch (err) {
        alert("Delete failed. Check backend route.");
      }
    }
  };

  return (
    <div className="container py-5">
      <div className="d-flex justify-content-between align-items-center mb-4 bg-light p-3 rounded-3 shadow-sm">
        <div>
          <h2 className="fw-bold mb-0">Admin Control Center</h2>
          <small className="text-muted">Manage your platform and users</small>
        </div>
        <span className="badge bg-danger px-3 py-2">Admin Mode</span>
      </div>

      <ul className="nav nav-pills mb-4 bg-white p-2 rounded shadow-sm border">
        <li className="nav-item">
          <button 
            className={`nav-link ${activeTab === "users" ? "active" : ""}`}
            onClick={() => setActiveTab("users")}
          >
            Manage Users
          </button>
        </li>
        <li className="nav-item">
          <button 
            className={`nav-link ${activeTab === "courses" ? "active" : ""}`}
            onClick={() => setActiveTab("courses")}
          >
            Manage Courses
          </button>
        </li>
      </ul>

      {loading ? (
        <div className="text-center my-5">
          <div className="spinner-border text-primary" role="status"></div>
        </div>
      ) : activeTab === "users" ? (
        <div className="card shadow-sm border-0 p-4">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h4 className="fw-bold mb-0">Registered Users ({users.length})</h4>
          </div>
          <div className="table-responsive">
            <table className="table table-hover mt-2">
              <thead className="table-light">
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Role</th>
                  <th className="text-end">Action</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u._id}>
                    <td>{u.name}</td>
                    <td>{u.email}</td>
                    <td>
                      <span className={`badge ${u.role === 'Admin' ? 'bg-dark' : 'bg-info text-dark'}`}>
                        {u.role}
                      </span>
                    </td>
                    <td className="text-end">
                      <button className="btn btn-sm btn-outline-danger" onClick={() => deleteUser(u._id)}>
                        Remove User
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="card shadow-sm border-0 p-4">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h4 className="fw-bold mb-0">Course Catalog ({courses.length})</h4>
            <button className="btn btn-success btn-sm">+ Add New Course</button>
          </div>
          
          <div className="table-responsive">
            <table className="table table-hover align-middle">
              <thead className="table-light">
                <tr>
                  <th>Preview</th>
                  <th>Title</th>
                  <th>Category</th>
                  <th>Price</th>
                  <th className="text-end">Action</th>
                </tr>
              </thead>
              <tbody>
                {courses.map((course) => (
                  <tr key={course.id || course._id}>
                    <td>
                      <img 
                        src={course.thumbnail} 
                        alt="thumb" 
                        style={{width: "60px", height: "40px", objectFit: "cover", borderRadius: "8px"}} 
                        onError={(e) => { e.target.src = "https://via.placeholder.com/60x40?text=No+Img"; }}
                      />
                    </td>
                    <td className="fw-bold">{course.title}</td>
                    <td><span className="badge bg-secondary-subtle text-secondary border">{course.category}</span></td>
                    <td className="fw-bold text-success">${course.price}</td>
                    <td className="text-end">
                      <button className="btn btn-sm btn-light border me-2">Edit</button>
                      <button className="btn btn-sm btn-danger" onClick={() => deleteCourse(course.id || course._id)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;