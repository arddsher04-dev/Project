import React, { useState } from "react";

const Faq = () => {
  const [activeIndex, setActiveIndex] = useState(null);

  const toggleAccordion = (index) => {
    // Functional update ensures state sync
    setActiveIndex((prevIndex) => (prevIndex === index ? null : index));
  };

  const faqData = [
    { 
      q: "What is the MERN Stack and why should I learn it?", 
      a: "MERN stands for MongoDB, Express, React, and Node.js. It is the most popular JavaScript stack in 2026. Learning it allows you to build full-stack applications using just one language: JavaScript." 
    },
    { 
      q: "Will I get a certificate after completing a course?", 
      a: "Yes! Once you complete all modules and pass the final project assessment, you will receive a verified digital certificate that you can add to your LinkedIn profile or resume." 
    },
    { 
      q: "Do I need prior coding experience?", 
      a: "Our curriculum is designed for everyone. While we have advanced 'Mastery' tracks, we also offer 'Beginner Paths' that start from the absolute basics of HTML, CSS, and JavaScript logic." 
    },
    { 
      q: "Is there a community for support if I get stuck?", 
      a: "Absolutely. All students get access to our private Discord community where senior developers and mentors are available 24/7 to help you debug your code." 
    },
    { 
      q: "Do you offer job placement or career assistance?", 
      a: "We provide dedicated career coaching for our PRO members, including resume reviews, mock interviews, and direct referrals to our network of partner tech companies." 
    },
    { 
      q: "What software/tools do I need to install?", 
      a: "All you need is a computer and an internet connection. We will guide you through installing VS Code, Node.js, and setting up your MongoDB Atlas account in the first module." 
    }
  ];

  return (
    <div className="container py-5 mt-5">
      <style>{`
        .accordion-collapse {
          transition: max-height 0.4s ease-out, opacity 0.3s ease;
          max-height: 0;
          overflow: hidden;
          opacity: 0;
          display: block; /* Overriding bootstrap default for smoother manual transition */
        }
        .accordion-collapse.show {
          max-height: 1000px; /* Large enough value for content */
          opacity: 1;
        }
        .accordion-button:not(.collapsed) {
          background-color: #f8fafc;
          color: #4f46e5;
          box-shadow: none;
        }
        .accordion-button:focus {
            box-shadow: none;
            border-color: rgba(0,0,0,.125);
        }
      `}</style>

      <div className="text-center mb-5">
        <h1 className="fw-bold display-5">Common Questions</h1>
        <p className="text-muted">Everything you need to know about our learning platform.</p>
      </div>

      <div className="row justify-content-center">
        <div className="col-lg-9">
          <div className="accordion accordion-flush shadow-sm rounded-4 border overflow-hidden">
            {faqData.map((item, index) => (
              <div className="accordion-item" key={index}>
                <h2 className="accordion-header">
                  <button 
                    className={`accordion-button ${activeIndex === index ? "" : "collapsed"} fw-semibold py-4 fs-5`} 
                    type="button"
                    onClick={() => toggleAccordion(index)}
                  >
                    {item.q}
                  </button>
                </h2>
                <div className={`accordion-collapse ${activeIndex === index ? "show" : ""}`}>
                  <div className="accordion-body text-secondary lh-lg py-4 bg-light-subtle border-top">
                    {item.a}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Faq;