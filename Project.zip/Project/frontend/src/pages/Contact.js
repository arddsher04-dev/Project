import React, { useState } from "react";

const Contact = () => {
  const [formData, setFormData] = useState({ name: "", email: "", subject: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    // Simulate API call
    console.log("Form Data:", formData);
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <div className="contact-wrapper py-5">
      <style>{`
        .contact-card { border: none; border-radius: 25px; overflow: hidden; }
        .info-sidebar { background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%); color: white; padding: 40px; }
        .form-input { border: 1px solid #e2e8f0; padding: 12px; border-radius: 10px; transition: 0.3s; }
        .form-input:focus { border-color: #4f46e5; box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.1); outline: none; }
        .contact-icon { width: 40px; height: 40px; background: rgba(255,255,255,0.2); border-radius: 10px; display: flex; align-items: center; justify-content: center; margin-right: 15px; }
      `}</style>

      <div className="container">
        <div className="text-center mb-5">
          <h1 className="fw-bold display-5">Get in <span className="text-primary">Touch</span></h1>
          <p className="text-muted">Have a technical question or need help with your subscription?</p>
        </div>

        <div className="card contact-card shadow-lg">
          <div className="row g-0">
            {/* LEFT SIDE: INFO */}
            <div className="col-lg-5 info-sidebar d-flex flex-column justify-content-between">
              <div>
                <h3 className="fw-bold mb-4">Contact Information</h3>
                <p className="opacity-75 mb-5">Fill out the form and our team will get back to you within 24 hours.</p>
                
                <div className="d-flex align-items-center mb-4">
                  <div className="contact-icon">📍</div>
                  <span>Tech Hub, Silicon Valley, CA</span>
                </div>
                <div className="d-flex align-items-center mb-4">
                  <div className="contact-icon">📧</div>
                  <span>support@edumern.com</span>
                </div>
                <div className="d-flex align-items-center mb-4">
                  <div className="contact-icon">📞</div>
                  <span>+1 (555) 000-MERN</span>
                </div>
              </div>

              <div className="d-flex gap-3">
                <a href="#" className="text-white opacity-75 hover-opacity-100">Twitter</a>
                <a href="#" className="text-white opacity-75 hover-opacity-100">LinkedIn</a>
                <a href="#" className="text-white opacity-75 hover-opacity-100">GitHub</a>
              </div>
            </div>

            {/* RIGHT SIDE: FORM */}
            <div className="col-lg-7 p-4 p-md-5 bg-white">
              {submitted ? (
                <div className="text-center py-5">
                  <div className="display-1 mb-3">✅</div>
                  <h3 className="fw-bold">Message Sent!</h3>
                  <p className="text-muted">Thanks for reaching out. We'll be in touch soon.</p>
                  <button className="btn btn-outline-primary mt-3" onClick={() => setSubmitted(false)}>Send another</button>
                </div>
              ) : (
                <form onSubmit={handleSubmit}>
                  <div className="row g-3">
                    <div className="col-md-6">
                      <label className="form-label small fw-bold">Your Name</label>
                      <input type="text" required className="form-control form-input" placeholder="John Doe" 
                        onChange={(e) => setFormData({...formData, name: e.target.value})} />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label small fw-bold">Email Address</label>
                      <input type="email" required className="form-control form-input" placeholder="john@example.com"
                        onChange={(e) => setFormData({...formData, email: e.target.value})} />
                    </div>
                    <div className="col-12">
                      <label className="form-label small fw-bold">Subject</label>
                      <select className="form-select form-input" onChange={(e) => setFormData({...formData, subject: e.target.value})}>
                        <option>General Inquiry</option>
                        <option>Technical Support</option>
                        <option>Billing Issue</option>
                        <option>Course Partnership</option>
                      </select>
                    </div>
                    <div className="col-12">
                      <label className="form-label small fw-bold">Message</label>
                      <textarea required className="form-control form-input" rows="5" placeholder="How can we help you?"
                        onChange={(e) => setFormData({...formData, message: e.target.value})}></textarea>
                    </div>
                    <div className="col-12 mt-4">
                      <button type="submit" className="btn btn-primary btn-lg w-100 rounded-pill fw-bold py-3 shadow">
                        Send Message
                      </button>
                    </div>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;