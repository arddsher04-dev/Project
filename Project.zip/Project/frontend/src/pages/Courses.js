import React, { useState, useEffect } from "react";
import axios from "axios";

function Courses() {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCourses();
  }, []);

  const fetchCourses = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/courses");
      setCourses(res.data);
    } catch (err) {
      console.error("Error fetching courses:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleEnroll = async (courseId) => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    if (!storedUser) {
      alert("Please login first to enroll!");
      return;
    }

    const userId = storedUser.id || storedUser._id;
    try {
      const response = await axios.post("http://localhost:5000/api/student/enroll", {
        userId,
        courseId
      });
      if (response.status === 200 || response.status === 201) {
        alert("🎉 Enrolled successfully!");
      }
    } catch (err) {
      alert(err.response?.data?.message || "Enrollment failed.");
    }
  };

  if (loading) {
    return (
      <div className="text-center mt-5 py-5">
        <div className="spinner-border text-indigo" role="status"></div>
        <h4 className="mt-3 text-indigo fw-bold">Curating Premium Courses...</h4>
      </div>
    );
  }

  return (
    <div className="container py-5 mt-5">
      <div className="text-center mb-5">
        <span className="badge bg-indigo-subtle text-indigo px-3 py-2 rounded-pill mb-2 fw-bold">COURSES</span>
        <h2 className="fw-bolder text-dark display-5">Unlock Your Potential</h2>
        <p className="text-muted mx-auto" style={{ maxWidth: "600px" }}>
          Choose from over 10+ professional courses designed to take you from beginner to industry-ready expert.
        </p>
      </div>

      <div className="row g-4">
        {courses.length > 0 ? (
          courses.map((course) => (
            <div className="col-sm-6 col-md-4 col-lg-3" key={course._id || course.id}>
              <div className="card h-100 border-0 shadow-sm rounded-4 overflow-hidden course-card">
                <div className="position-relative">
                  <img
                    src={course.thumbnail}
                    className="card-img-top"
                    alt={course.title}
                    style={{ height: "180px", objectFit: "cover" }}
                    loading="lazy" // Better performance
                    onError={(e) => {
                      e.target.onerror = null;
                      e.target.src = "https://images.unsplash.com/photo-1501504905252-473c47e087f8?w=800"; // General fallback
                    }}
                  />
                  <div className="position-absolute top-0 start-0 m-2">
                    <span className="badge bg-dark opacity-75">{course.category}</span>
                  </div>
                </div>

                <div className="card-body d-flex flex-column p-4">
                  <h6 className="fw-bold text-dark mb-2 lh-base" style={{ height: "45px", overflow: "hidden" }}>
                    {course.title}
                  </h6>
                  <p className="text-muted small mb-4" style={{ fontSize: "0.85rem" }}>
                    {course.description?.substring(0, 65)}...
                  </p>

                  <div className="mt-auto d-flex align-items-center justify-content-between border-top pt-3">
                    <span className="fw-bolder text-indigo fs-5">${course.price}</span>
                    <button
                      className="btn btn-indigo rounded-pill btn-sm px-3 fw-bold"
                      onClick={() => handleEnroll(course._id || course.id)}
                    >
                      Enroll Now
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-5">
            <h4 className="text-muted">No courses available at the moment.</h4>
          </div>
        )}
      </div>
    </div>
  );
}

export default Courses;