import React, { useState, useEffect } from "react";

const Profile = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    // Get user data from localStorage
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  if (!user) {
    return (
      <div className="container mt-5 pt-5 text-center">
        <h4>Please login to view your profile.</h4>
      </div>
    );
  }

  return (
    <div className="container mt-5 pt-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card border-0 shadow-lg rounded-4 overflow-hidden">
            {/* Profile Header Background */}
            <div className="bg-indigo py-5 text-center">
              <div 
                className="rounded-circle bg-white d-inline-flex align-items-center justify-content-center shadow"
                style={{ width: "120px", height: "120px", fontSize: "3rem", color: "#6366f1", fontWeight: "bold" }}
              >
                {user.name.charAt(0).toUpperCase()}
              </div>
            </div>

            {/* Profile Details */}
            <div className="card-body p-5 text-center">
              <h2 className="fw-bold mb-1">{user.name}</h2>
              <p className="text-muted mb-4">{user.role} Account</p>
              
              <div className="text-start bg-light p-4 rounded-3">
                <div className="mb-3">
                  <label className="small text-uppercase fw-bold text-muted">Full Name</label>
                  <p className="mb-0 fw-semibold">{user.name}</p>
                </div>
                <div className="mb-3">
                  <label className="small text-uppercase fw-bold text-muted">Email Address</label>
                  <p className="mb-0 fw-semibold">{user.email}</p>
                </div>
                <div className="mb-0">
                  <label className="small text-uppercase fw-bold text-muted">Account Type</label>
                  <p className="mb-0">
                    <span className="badge bg-indigo-subtle text-indigo px-3 py-2 rounded-pill">
                      {user.role}
                    </span>
                  </p>
                </div>
              </div>

              <button className="btn btn-indigo w-100 mt-4 py-2 rounded-pill fw-bold">
                Edit Profile
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;