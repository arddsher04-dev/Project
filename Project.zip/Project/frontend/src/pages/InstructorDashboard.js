import React, { useState, useEffect } from "react";
import axios from "axios";

const InstructorDashboard = () => {
  const [myCourses, setMyCourses] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingCourse, setEditingCourse] = useState(null);

  const initialFormState = {
    title: "", description: "", price: "", category: "", thumbnail: "", lessons: []
  };

  const [formData, setFormData] = useState(initialFormState);

  const user = JSON.parse(localStorage.getItem("user"));

  useEffect(() => {
    if (user && user.id) {
      fetchMyCourses();
    }
  }, []);

  const fetchMyCourses = async () => {
    try {
      const res = await axios.get(`http://localhost:5000/api/instructor/courses/${user.id}`);
      setMyCourses(res.data);
    } catch (err) {
      console.error("Error fetching courses", err);
    }
  };

  const openModal = (course = null) => {
    if (course) {
      setEditingCourse(course);
      setFormData(course);
    } else {
      setEditingCourse(null);
      setFormData(initialFormState); 
    }
    setShowModal(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      if (editingCourse) {
        await axios.put(`http://localhost:5000/api/courses/${editingCourse._id}`, formData);
        alert("Course updated successfully!");
      } else {
        await axios.post("http://localhost:5000/api/courses/create", { 
          ...formData, 
          instructorId: user.id 
        });
        alert("Course created successfully!");
      }
      setShowModal(false);
      fetchMyCourses();
    } catch (err) {
      alert("Action failed. Make sure backend routes are working.");
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this course?")) {
      try {
        await axios.delete(`http://localhost:5000/api/courses/${id}`);
        alert("Course deleted!");
        fetchMyCourses();
      } catch (err) {
        alert("Delete failed.");
      }
    }
  };

  const addLessonField = () => {
    setFormData({ 
      ...formData, 
      lessons: [...formData.lessons, { title: "", videoUrl: "", duration: "" }] 
    });
  };

  return (
    <div className="container py-5">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 className="fw-bold">Instructor Studio</h2>
        <button className="btn btn-primary shadow-sm" onClick={() => openModal()}>
          + Create New Course
        </button>
      </div>

      <div className="row">
        {myCourses.length > 0 ? (
          myCourses.map((course) => (
            <div className="col-md-4 mb-4" key={course._id}>
              <div className="card shadow-sm border-0 h-100">
                <img src={course.thumbnail} className="card-img-top" height="180" style={{ objectFit: 'cover' }} alt={course.title} />
                <div className="card-body d-flex flex-column">
                  <h6 className="fw-bold">{course.title}</h6>
                  <p className="text-muted small flex-grow-1">{course.description?.substring(0, 60)}...</p>
                  <div className="d-flex gap-2 mt-3">
                    <button className="btn btn-sm btn-outline-dark flex-grow-1" onClick={() => openModal(course)}>Edit</button>
                    <button className="btn btn-sm btn-danger" onClick={() => handleDelete(course._id)}>Delete</button>
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-5">
            <p className="text-muted">No courses found. Create your first course!</p>
          </div>
        )}
      </div>

      {/* Course Modal */}
      {showModal && (
        <div className="modal show d-block shadow-lg" style={{ background: "rgba(0,0,0,0.7)" }}>
          <div className="modal-dialog modal-lg modal-dialog-centered">
            <div className="modal-content p-4 border-0" style={{ borderRadius: "15px" }}>
              <div className="d-flex justify-content-between mb-3">
                <h4 className="fw-bold">{editingCourse ? "Edit Course" : "Create New Course"}</h4>
                <button className="btn-close" onClick={() => setShowModal(false)}></button>
              </div>
              
              <form onSubmit={handleSave} style={{ maxHeight: "70vh", overflowY: "auto", overflowX: "hidden", paddingRight: "10px" }}>
                <div className="mb-3">
                  <label className="form-label small fw-bold">Course Title</label>
                  <input className="form-control" placeholder="e.g. React Mastery" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} required />
                </div>
                
                <div className="row">
                    <div className="col-md-6 mb-3">
                        <label className="form-label small fw-bold">Price ($)</label>
                        <input type="number" className="form-control" value={formData.price} onChange={e => setFormData({...formData, price: e.target.value})} required />
                    </div>
                    <div className="col-md-6 mb-3">
                        <label className="form-label small fw-bold">Category</label>
                        <input className="form-control" placeholder="Web Dev" value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} required />
                    </div>
                </div>

                <div className="mb-3">
                  <label className="form-label small fw-bold">Thumbnail URL</label>
                  <input className="form-control" value={formData.thumbnail} onChange={e => setFormData({...formData, thumbnail: e.target.value})} required />
                </div>

                <div className="mb-3">
                  <label className="form-label small fw-bold">Description</label>
                  <textarea className="form-control" rows="3" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
                </div>
                
                <h5 className="mt-4 border-bottom pb-2">Lessons</h5>
                {formData.lessons.map((lesson, index) => (
                  <div key={index} className="bg-light p-3 mb-2 rounded shadow-sm border">
                    <input className="form-control mb-2" placeholder="Lesson Title" value={lesson.title} onChange={e => {
                      const newLessons = [...formData.lessons];
                      newLessons[index].title = e.target.value;
                      setFormData({...formData, lessons: newLessons});
                    }} required />
                    <input className="form-control" placeholder="Video URL (YouTube/MP4)" value={lesson.videoUrl} onChange={e => {
                      const newLessons = [...formData.lessons];
                      newLessons[index].videoUrl = e.target.value;
                      setFormData({...formData, lessons: newLessons});
                    }} required />
                  </div>
                ))}
                
                <button type="button" className="btn btn-sm btn-secondary w-100 mb-4" onClick={addLessonField}>+ Add Lesson</button>
                
                <div className="d-flex gap-2 sticky-bottom bg-white py-2">
                  <button type="submit" className="btn btn-success flex-grow-1 py-2 fw-bold">Save Course</button>
                  <button type="button" className="btn btn-light px-4" onClick={() => setShowModal(false)}>Cancel</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InstructorDashboard;