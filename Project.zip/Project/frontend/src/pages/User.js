import React from 'react';

const User = () => {
  return (
    <div className="container mt-5">
      <div className="card shadow p-4 border-0" style={{borderRadius: "20px"}}>
        <h2 className="fw-bold text-primary">User Profile</h2>
        <hr />
        <p className="lead">This is where the user information will be displayed after fetching it from the database.</p>
        
        <div className="mt-3">
          <button className="btn btn-outline-primary me-2">Edit Profile</button>
          <button className="btn btn-danger">Logout</button>
        </div>
      </div>
    </div>
  );
};

export default User;