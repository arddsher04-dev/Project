import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

const Login = () => {
  const [credentials, setCredentials] = useState({ email: "", password: "", role: "Student" });
  const navigate = useNavigate();

  // Redirect if already logged in
  useEffect(() => {
    const user = localStorage.getItem("user");
    if (user) {
      const parsedUser = JSON.parse(user);
      if (parsedUser.role === "Student") navigate("/student-dashboard");
      else if (parsedUser.role === "Instructor") navigate("/instructor-dashboard");
      else if (parsedUser.role === "Admin") navigate("/admin-dashboard");
    }
  }, [navigate]);

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:5000/api/auth/login", credentials);
      
      if (response.data.user) {
        // 1. Save user to LocalStorage
        localStorage.setItem("user", JSON.stringify(response.data.user));
        

        // 2. USE window.location.href INSTEAD OF navigate()
        // This forces the Navbar to re-render and show the username
        const userRole = response.data.user.role;
        if (userRole === "Student") window.location.href = "/student-dashboard";
        else if (userRole === "Instructor") window.location.href = "/instructor-dashboard";
        else if (userRole === "Admin") window.location.href = "/admin-dashboard";
        else window.location.href = "/dashboard";
      }

    } catch (err) {
      console.error("Login Error Details:", err.response?.data);
      alert("Login Failed: " + (err.response?.data?.error || "Invalid Credentials"));
    }
  };

  return (
    <div className="login-container min-vh-100 d-flex align-items-center bg-light">
      <style>{`
        .login-card { border-radius: 30px; border: none; overflow: hidden; }
        .login-side-content { background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%); color: white; padding: 60px; }
        .form-control-lg { border-radius: 12px; font-size: 1rem; padding: 12px 20px; background-color: #f8fafc; }
        .btn-login { background: #4f46e5; border: none; padding: 12px; border-radius: 12px; transition: 0.3s; }
        .btn-login:hover { background: #4338ca; transform: translateY(-2px); }
      `}</style>

      <div className="container">
        <div className="row justify-content-center">
          <div className="col-lg-10">
            <div className="card login-card shadow-lg">
              <div className="row g-0">
                <div className="col-md-5 d-none d-md-flex login-side-content flex-column justify-content-center">
                  <h2 className="display-6 fw-bold mb-4">Welcome Back</h2>
                  <p className="lead opacity-75">Enter your details to access your dashboard.</p>
                </div>

                <div className="col-md-7 bg-white p-4 p-lg-5">
                  <h3 className="fw-bold mb-4">Sign In</h3>
                  <form onSubmit={handleLogin}>
                    <div className="mb-3">
                      <label className="form-label small fw-bold">Login as</label>
                      <select className="form-select form-control-lg" name="role" value={credentials.role} onChange={handleChange}>
                        <option value="Student">Student</option>
                        <option value="Instructor">Instructor</option>
                        <option value="Admin">Admin</option>
                      </select>
                    </div>
                    <div className="mb-3">
                      <label className="form-label small fw-bold">Email</label>
                      <input 
                        type="email" 
                        name="email" 
                        value={credentials.email}
                        className="form-control form-control-lg" 
                        placeholder="email@example.com" 
                        required 
                        onChange={handleChange} 
                      />
                    </div>
                    <div className="mb-4">
                      <label className="form-label small fw-bold">Password</label>
                      <input 
                        type="password" 
                        name="password" 
                        value={credentials.password}
                        className="form-control form-control-lg" 
                        placeholder="••••••••" 
                        required 
                        onChange={handleChange} 
                      />
                    </div>
                    <button type="submit" className="btn btn-primary btn-login btn-lg w-100 mb-4 fw-bold shadow">Sign In</button>
                    <p className="text-center text-muted">New here? <Link to="/register" className="text-primary fw-bold text-decoration-none">Create Account</Link></p>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;