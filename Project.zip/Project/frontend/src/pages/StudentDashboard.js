import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const StudentDashboard = () => {
  const [enrolledCourses, setEnrolledCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const user = JSON.parse(localStorage.getItem("user"));

  useEffect(() => {
    const fetchEnrolledCourses = async () => {
      try {
        if (user && (user.id || user._id)) {
          const userId = user.id || user._id;
          const res = await axios.get(`http://localhost:5000/api/student/my-courses/${userId}`);
          setEnrolledCourses(res.data);
        }
      } catch (err) {
        console.error("Error loading dashboard:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchEnrolledCourses();
  }, []);

  if (loading) {
    return (
      <div className="container mt-5 pt-5 text-center">
        <div className="spinner-border text-indigo" role="status"></div>
        <p className="mt-3">Loading your learning path...</p>
      </div>
    );
  }

  return (
    <div className="container mt-5 pt-5">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 className="fw-bold">My Dashboard</h2>
          <p className="text-muted">Welcome back, {user?.name}! Ready to learn?</p>
        </div>
        <Link to="/courses" className="btn btn-indigo rounded-pill px-4">
          Browse More Courses
        </Link>
      </div>

      <div className="row">
        {enrolledCourses.length > 0 ? (
          enrolledCourses.map((course) => (
            <div className="col-md-4 mb-4" key={course._id}>
              <div className="card shadow-sm border-0 h-100 overflow-hidden rounded-3">
                <img 
                  src={course.thumbnail} 
                  className="card-img-top" 
                  alt={course.title}
                  style={{ height: "180px", objectFit: "cover" }}
                  onError={(e) => { e.target.src = "https://via.placeholder.com/400x250?text=Course+Image"; }}
                />
                <div className="card-body">
                  <span className="badge bg-indigo-subtle text-indigo mb-2">{course.category}</span>
                  <h5 className="fw-bold mb-3">{course.title}</h5>
                  <div className="progress mb-3" style={{ height: "8px" }}>
                    <div className="progress-bar bg-indigo" style={{ width: "25%" }}></div>
                  </div>
                  <div className="d-flex justify-content-between align-items-center">
                    <span className="text-muted small">25% Complete</span>
                    <button className="btn btn-outline-indigo btn-sm rounded-pill px-3">
                      Continue
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="col-12 text-center py-5 bg-light rounded-4">
            <h4 className="text-muted">You are not enrolled in any courses yet.</h4>
            <p>Start your journey today by exploring our top-rated courses.</p>
            <Link to="/courses" className="btn btn-indigo mt-2 px-5 py-2 rounded-pill shadow">
              Explore Courses
            </Link>
          </div>
        )}
      </div>
    </div>
  );
};

export default StudentDashboard;