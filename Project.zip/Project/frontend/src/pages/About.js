import React from "react";
import { Link } from "react-router-dom";

const About = () => {
  return (
    <div className="about-page">
      <style>{`
        .hero-gradient {
          background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
          padding: 100px 0;
          color: white;
        }
        .stats-card {
          border: none;
          border-radius: 20px;
          transition: transform 0.3s;
          background: #f8fafc;
        }
        .stats-card:hover { transform: translateY(-5px); }
        .team-img {
          width: 120px;
          height: 120px;
          object-fit: cover;
          border-radius: 50%;
          border: 4px solid #4f46e5;
        }
      `}</style>

      {/* HERO SECTION */}
      <section className="hero-gradient text-center">
        <div className="container">
          <span className="badge bg-primary mb-3 px-3 py-2">OUR MISSION</span>
          <h1 className="display-3 fw-bold mb-4">Bridging the gap between <br/> <span className="text-primary">Learning</span> and <span className="text-info">Earning</span></h1>
          <p className="lead opacity-75 mx-auto" style={{maxWidth: '700px'}}>
            EduMERN was founded in 2024 with a simple goal: to provide world-class engineering education that is project-based, affordable, and accessible to everyone.
          </p>
        </div>
      </section>

      {/* STORY SECTION */}
      <section className="py-5">
        <div className="container py-5">
          <div className="row align-items-center g-5">
            <div className="col-lg-6">
              <h2 className="fw-bold mb-4">Why we started EduMERN</h2>
              <p className="text-muted">Most online courses teach you syntax, but they don't teach you how to build systems. We noticed a massive gap between what students learn in bootcamps and what senior engineers actually do at companies like Google and Meta.</p>
              <p className="text-muted">We decided to change that by focusing 100% on **Project-Based Learning**. Every course on our platform results in a production-ready application you can proudly show to recruiters.</p>
              <div className="d-flex gap-3 mt-4">
                <div className="text-center p-3 stats-card flex-fill">
                  <h3 className="fw-bold text-primary">50k+</h3>
                  <small className="text-muted">Students</small>
                </div>
                <div className="text-center p-3 stats-card flex-fill">
                  <h3 className="fw-bold text-primary">120+</h3>
                  <small className="text-muted">Countries</small>
                </div>
              </div>
            </div>
            <div className="col-lg-6">
              <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=800" alt="Team" className="img-fluid rounded-5 shadow-lg" />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;