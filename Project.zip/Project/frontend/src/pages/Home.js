import React from "react";
import { Link } from "react-router-dom";
import "./Home.css";

function Home() {
  return (
    <div className="home-container">
      {/* HERO SECTION */}
      <section className="hero-wrapper">
        <div className="container text-center text-lg-start">
          <div className="row align-items-center py-5">
            <div className="col-lg-6">
              <span className="badge bg-soft-primary text-primary mb-3 px-3 py-2 text-uppercase fw-bold">
                Elite Learning Experience
              </span>
              <h1 className="display-2 fw-bold mb-4">
                Level up your <br />
                <span className="gradient-text">Engineering</span> skills.
              </h1>
              <p className="lead mb-5 text-light opacity-75">
                Master the MERN stack with project-based curriculum designed by
                senior developers from FAANG companies.
              </p>
              <div className="d-flex flex-column flex-sm-row gap-3">
                <Link to="/courses" className="btn btn-primary btn-xl shadow-lg">Start Learning Free</Link>
                <Link to="/register" className="btn btn-outline-light btn-xl">View Curriculum</Link>
              </div>
            </div>
            <div className="col-lg-6 d-none d-lg-block">
              <div className="hero-image-stack">
                {/* Visual Representation of a Dashboard */}
                <div className="glass-card main-hero-card p-4">
                  <div className="d-flex align-items-center mb-4">
                    <div className="avatar me-3">JD</div>
                    <div>
                      <h6 className="mb-0">John Doe</h6>
                      <small className="opacity-50">Mastering React Hooks...</small>
                    </div>
                  </div>
                  <div className="progress mb-3" style={{ height: "8px" }}>
                    <div className="progress-bar bg-info" style={{ width: "75%" }}></div>
                  </div>
                  <div className="d-flex justify-content-between small text-white-50">
                    <span>75% Completed</span>
                    <span>Next: Redux Saga</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* TRUSTED BY BANNER */}
      <div className="bg-light py-4 border-bottom">
        <div className="container">
          <p className="text-center text-uppercase small fw-bold text-muted mb-3">Instructors from world-class companies</p>
          <div className="d-flex justify-content-around align-items-center opacity-50 grayscale-filter">
            <h4 className="fw-bold">Google</h4>
            <h4 className="fw-bold">Meta</h4>
            <h4 className="fw-bold">Netflix</h4>
            <h4 className="fw-bold">Amazon</h4>
          </div>
        </div>
      </div>

      {/* REFINED FEATURES SECTION */}
      <section className="py-5">
        <div className="container py-5">
          <div className="row g-4 text-start">
            {[
              { icon: "💡", title: "Project-Based", desc: "Build 10+ real-world applications including an E-commerce site and Social Media." },
              { icon: "📜", title: "Certificate", desc: "Get an industry-recognized certificate upon completion of each specialized track." },
              { icon: "🤝", title: "1:1 Mentorship", desc: "Access to private Discord channels for direct support from senior developers." }
            ].map((f, i) => (
              <div className="col-md-4" key={i}>
                <div className="card h-100 feature-card p-4">
                  <div className="icon-box mb-3">{f.icon}</div>
                  <h4 className="fw-bold">{f.title}</h4>
                  <p className="text-muted mb-0">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* STATS SECTION */}
      <section className="stats-section my-5 mx-3 rounded-5">
        <div className="container text-center">
          <div className="row g-4">
            {[
              { v: "50k+", l: "Students" },
              { v: "120+", l: "Courses" },
              { v: "4.9/5", l: "Rating" },
              { v: "98%", l: "Job Rate" }
            ].map((s, i) => (
              <div className="col-6 col-md-3" key={i}>
                {/* text-primary class dono par apply kar di */}
                <h2 className="stat-number text-primary fw-bold">{s.v}</h2>
                <p className="text-primary mb-0">{s.l}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* IMPROVED CTA BOX: EDUCATION THEMED */}
      <section className="container mb-5">
        <div className="cta-box shadow-lg position-relative overflow-hidden p-5 rounded-5">
          {/* Decorative background flare */}
          <div className="cta-flare"></div>

          <div className="position-relative z-index-1">
            <h2 className="display-4 fw-bold mb-3 text-white">
              Start Your <span className="text-warning"> Knowledge Pass</span>
            </h2>
            <p className="mb-4 lead text-white-50 mx-auto" style={{ maxWidth: "700px" }}>
              Gain full access to our expert-led curriculum, interactive coding labs,
              and industry-recognized certifications. Elevate your skills today.
            </p>

            <div className="d-flex flex-column align-items-center">
              <Link to="/register" className="btn btn-warning btn-xl px-5 py-3 fw-bold rounded-pill mb-3 shadow-lg">
                Start Learning for Free
              </Link>
              <div className="d-flex gap-4 mt-2">
                <span className="text-white-50 small">✅ Unlimited Course Access</span>
                <span className="text-white-50 small">✅ Professional Certificates</span>
                <span className="text-white-50 small">✅ Mentor Support</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
export default Home;