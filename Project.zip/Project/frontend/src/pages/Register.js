import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom"; // Use useNavigate for better React flow
import axios from "axios";

const Register = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        name: "",
        email: "",
        password: "",
        role: "Student"
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleRegister = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post("http://localhost:5000/api/auth/register", formData);
            
            // 1. Save user info so the dashboard can greet them
            localStorage.setItem("user", JSON.stringify(response.data.user || { name: formData.name, role: formData.role }));
            
            alert("Registration Successful!");

            // 2. Direct them to their specific dashboard
            if (formData.role === "Student") {
                navigate("/student-dashboard");
            } else if (formData.role === "Instructor") {
                navigate("/instructor-dashboard");
            } else {
                navigate("/dashboard");
            }

        } catch (err) {
            alert("Registration Failed: " + (err.response?.data?.error || "Server Error"));
        }
    };

    return (
        <div className="register-container min-vh-100 d-flex align-items-center bg-light py-5">
            <style>{`
                .register-card { border-radius: 30px; border: none; overflow: hidden; }
                .role-option { cursor: pointer; border: 2px solid #e2e8f0; border-radius: 12px; padding: 10px; transition: 0.3s; flex: 1; }
                .role-option.active { border-color: #4f46e5; background-color: rgba(79, 70, 229, 0.05); color: #4f46e5; }
                .form-control-lg { border-radius: 12px; font-size: 1rem; padding: 12px 20px; }
            `}</style>

            <div className="container">
                <div className="row justify-content-center">
                    <div className="col-lg-11 col-xl-10">
                        <div className="card register-card shadow-lg">
                            <div className="row g-0">
                                <div className="col-md-5 d-none d-md-flex bg-primary text-white p-5 flex-column justify-content-center"
                                    style={{ background: "linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%)" }}>
                                    <h2 className="display-5 fw-bold mb-4">Join EduMERN</h2>
                                    <p className="lead opacity-75">Start your learning journey today.</p>
                                </div>

                                <div className="col-md-7 bg-white p-4 p-lg-5">
                                    <h3 className="fw-bold mb-4">Create Account</h3>
                                    <form onSubmit={handleRegister}>
                                        <div className="mb-4">
                                            <label className="form-label small fw-bold d-block mb-3">Registering as a:</label>
                                            <div className="d-flex gap-2">
                                                {["Student", "Instructor", "Admin"].map((r) => (
                                                    <div key={r} className={`role-option text-center ${formData.role === r ? 'active' : ''}`}
                                                        onClick={() => setFormData({ ...formData, role: r })}>
                                                        <div className="small fw-bold">{r}</div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>

                                        <div className="mb-3">
                                            <label className="form-label small fw-bold">Full Name</label>
                                            <input type="text" name="name" className="form-control form-control-lg" placeholder="John Doe" required onChange={handleChange} />
                                        </div>

                                        <div className="mb-3">
                                            <label className="form-label small fw-bold">Email Address</label>
                                            <input type="email" name="email" className="form-control form-control-lg" placeholder="john@example.com" required onChange={handleChange} />
                                        </div>

                                        <div className="mb-4">
                                            <label className="form-label small fw-bold">Password</label>
                                            <input type="password" name="password" className="form-control form-control-lg" placeholder="••••••••" required onChange={handleChange} />
                                        </div>

                                        <button type="submit" className="btn btn-primary btn-lg w-100 rounded-pill fw-bold py-3 shadow mb-4">
                                            Register as {formData.role}
                                        </button>
                                        <p className="text-center text-muted">Already have an account? <Link to="/login" className="text-primary fw-bold text-decoration-none">Log In</Link></p>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Register;